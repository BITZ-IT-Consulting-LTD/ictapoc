# Child Welfare Society of Kenya – Service Delivery

## Cover Page
- **Ministry/Department/Agency (MDA):** Child Welfare Society of Kenya
- **Process Name:** Service Delivery
- **Document Version:** 1.0
- **Date:** 2026-02-14
- **Classification:** Official

---

## Executive Summary
The Child Welfare Society of Kenya (CWSK) is a national non-governmental organization, established and gazetted in 1955 and governed by an irrevocable Trust Deed of 1970. CWSK serves as the National Adoption Society for Kenya and the National Emergency Response, Welfare, and Rescue Organization for children. Its mandate is to promote and secure the rights of children and young persons, provide comprehensive services to marginalized children across social sectors, and protect vulnerable children on behalf of the government, with the overarching aim for all children to lead happy, fulfilling, and fruitful lives.

---

## Service Mandate & Legal Basis
### Statutory Mandate
To ensure child protection by safeguarding children from abuse, neglect, and exploitation; to provide emergency preparedness, rapid response, and rescue services for separated, lost, or distressed children; to facilitate alternative family care, including child adoption, foster care for orphans and vulnerable children, and guardianship placements, to ensure children grow up in stable family environments; to offer rehabilitation services for children in need, including those affected by abuse, neglect, or those in conflict with the law; to advocate for children's rights and promote their needs at community, county, and national levels; to support vulnerable groups, such as children affected by HIV/AIDS, child labor, and street children, through identification, rescue, rehabilitation, and family tracing; to provide education and skills development through early childhood education support, primary, secondary, and university education sponsorships, and vocational skills training; to offer counseling and family support, including psychological support, crisis intervention, and family tracing and reunification services; to counter child trafficking by supporting victims and building capacity among stakeholders; and to operate rescue shelters and safe houses for children in immediate need of care and protection.

### Legal Context
- Established and gazetted in 1955, and governed by an irrevocable Trust Deed of 1970. CWSK's mandate aligns with Section 56 of the Kenyan Constitution, which guarantees children's rights, and it operates under the Ministry of Labour and Social Protection (specifically the Department of Children Services). Its activities are guided by the Children Act, 2022, and other relevant national and international child protection policies, conventions (e.g., UN Convention on the Rights of the Child), and best practices.

---

## 1. AS-IS Process Flowchart (BPMN 2.0)
*Current State visualization.*

```mermaid
graph TD
    Start((Start)) --> S1
    subgraph Professional [Professional]
        S1["Professional registers on the Board's Online Porta..."]
        S2["Applicant uploads academic certificates and profes..."]
        S4["Applicant pays the registration/annual retention f..."]
    end
    subgraph Board [Board]
        S3["Board Secretariat conducts verification and indexi..."]
        S5["Board gazettes the member and issues the Annual Pr..."]
    end
    S1 --> S2
    S2 --> S3
    S3 --> S4
    S4 --> S5
    S5 --> End((End))
```

---

## Process Overview
### Service Category
- G2C/G2B

### Scope
- **In Scope:** End-to-end processing within Child Welfare Society of Kenya.

### Triggers
- Submission of application/request by Professional.

### End States
- **Successful:** License / Permit / Certificate, Compliance Inspection Report, Official Receipt, Gazette Notice

---

## Stakeholders
| Stakeholder | Role | Responsibilities |
|---|---|---|
| Professional | Process Actor | Performs actions as defined in steps. |
| Board | Process Actor | Performs actions as defined in steps. |

---

## Inputs & Outputs
- **Inputs:** Application Form (License/Permit), Compliance Documents (Tax Compliance, CR12), Technical Reports / Site Plans, Proof of Payment
- **Outputs:** License / Permit / Certificate, Compliance Inspection Report, Official Receipt, Gazette Notice

---

## Detailed Process (AS-IS)
| Step | Role | Action | Tool | Notes |
|---|---|---|---|---|
| 1 | Professional | Professional registers on the Board's Online Portal. | Digital | |
| 2 | Professional | Applicant uploads academic certificates and professional testimonials. | Manual | |
| 3 | Board | Board Secretariat conducts verification and indexing. | Manual | |
| 4 | Professional | Applicant pays the registration/annual retention fee. | Manual | |
| 5 | Board | Board gazettes the member and issues the Annual Practicing Certificate. | Manual | |

---

## Pain Points & Opportunities
### Pain Points
- Manual document verification takes time.
- High cost and time for physical inspections.
- Risk of counterfeit licenses/certificates.
- Lack of real-time monitoring of licensees.

### Opportunities
- Integration with IPRS/BRS via Service Bus.
- Adoption of Government Payment Gateway.
- Implementation of Automated Rules Engine.
- Issuance of Digital Verifiable Credentials.

---

## 2. TO-BE Process Flowchart (BPMN 2.0)
*Future State visualization (Optimized with Service Bus & Registries).*

```mermaid
graph TD
    Start((Start)) --> S1
    subgraph Applicant [Applicant]
        S1["Applicant logs in via Single Sign-On (SSO) and sel..."]
        S4["Applicant pays fees via the Government Payment Gat..."]
    end
    subgraph System [System]
        S2["Applicant enters Business Registration Number; Sys..."]
        S3["System performs auto-validation of compliance (e.g..."]
        S5["Application is processed by the Rules Engine. (Low..."]
        S7["System generates a Verifiable Digital Certificate ..."]
    end
    subgraph Officer [Officer]
        S6["Complex cases are routed to the Officer Workbench ..."]
    end
    S1 --> S2
    S2 --> S3
    S3 --> S4
    S4 --> S5
    S5 --> S6
    S6 --> S7
    S7 --> End((End))
```

## Future State Process (TO-BE)
### Narrative
The To-Be process leverages the Government Service Bus to integrate with BRS (Business Registry) and the Payment Gateway. Manual data entry and document uploads are replaced by real-time API validations, enabling a paperless, cashless, and presence-less service experience.

### Optimized Steps (Digital)
| Step | Actor | Action | System |
|---|---|---|---|
| 1 | Applicant | Applicant logs in via Single Sign-On (SSO) and selects the service. | Citizen Portal / SSO |
| 2 | System | Applicant enters Business Registration Number; System auto-populates details from BRS (Business Registry) via the Service Bus. | Service Bus / Registry API |
| 3 | System | System performs auto-validation of compliance (e.g., KRA Tax Status) via Inter-Agency APIs. | Service Bus / Compliance Engine |
| 4 | Applicant | Applicant pays fees via the Government Payment Gateway; System auto-receipts. | Payment Gateway |
| 5 | System | Application is processed by the Rules Engine. (Low-risk cases are Auto-Approved). | Workflow Engine |
| 6 | Officer | Complex cases are routed to the Officer Workbench for digital review and approval. | Officer Workbench |
| 7 | System | System generates a Verifiable Digital Certificate (QR Code) and notifies the applicant. | Output Generator |

---

## References & Evidence
The information in this document was derived from the following official sources:

- [https://www.cwsk.go.ke/](https://www.cwsk.go.ke/)
- [https://childwelfare.or.ke/](https://childwelfare.or.ke/)
- [https://saraka.info/](https://saraka.info/)
- [https://youtube.com/](https://youtube.com/)
