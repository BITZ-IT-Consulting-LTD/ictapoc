# STANDARD BPM TEMPLATE – Agri and Cooperative Training and Consultancy Services Limted (subsidary of Cooperative University)

## Cover Page
- **Ministry/Department/Agency (MDA):** Agri and Cooperative Training and Consultancy Services Limted (subsidary of Cooperative University)
- **Process Name:** To extend academic knowledge in agribusiness, co-operative rural development, and related economic sectors to various stakeholders; to enhance businesses by offering comprehensive capacity development, training, consultancy, and research services; to offer quality and specialized short courses for farmers, small-scale entrepreneurs, co-operative societies (including SACCOs), and other relevant stakeholders; to provide training in diverse fields such as agriculture, ICT, monitoring and evaluation, project management, food security, leadership, climate change, and GIS & remote sensing; to conduct consultancies focused on improving interventions and providing business solutions in agriculture and rural development, aligning with national goals like Kenya Vision 2030 and the Agricultural Sector Development Strategy; and to collaborate with clients and provide scientific research findings to aid in informed decision-making within the sector.
- **Document Version:** 1.0
- **Date:** 2026-02-14
- **Classification:** Official

---

## Executive Summary
Agri and Cooperative Training and Consultancy Services Limited (ATC) is a capacity development and consultancy services provider wholly owned by the Co-operative University of Kenya (CUK). Its primary mandate is to extend the academic knowledge and expertise of CUK to various groups within and outside the co-operative movement and the agricultural sector. ATC offers specialized training, consultancy, and research services aimed at enhancing businesses and improving interventions in agribusiness and rural development. Operating on a commercial and cost-recovery basis, ATC delivers competitive and cost-effective solutions aligned with Kenya's national development needs.

---

## Process Flowchart (BPMN 2.0 - Mermaid)
*Guidance: This diagram visualizes the process flow across different actors (Swimlanes).*

```mermaid
graph TD
    Start((Start)) --> S1
    subgraph Student [Student]
        S1["Student receives placement notification via KUCCPS..."]
        S2["Student logs into the Institution's Student Portal..."]
        S3["Student pays tuition and statutory fees via Bank o..."]
        S4["Student physically reports to the institution for ..."]
        S6["Student is issued a Student ID card."]
    end
    subgraph Registrar [Registrar]
        S5["Institution registers the student in the ERP syste..."]
    end
    S1 --> S2
    S2 --> S3
    S3 --> S4
    S4 --> S5
    S5 --> S6
    S6 --> End((End))
```

---

## Process Overview
### Process Name
To extend academic knowledge in agribusiness, co-operative rural development, and related economic sectors to various stakeholders; to enhance businesses by offering comprehensive capacity development, training, consultancy, and research services; to offer quality and specialized short courses for farmers, small-scale entrepreneurs, co-operative societies (including SACCOs), and other relevant stakeholders; to provide training in diverse fields such as agriculture, ICT, monitoring and evaluation, project management, food security, leadership, climate change, and GIS & remote sensing; to conduct consultancies focused on improving interventions and providing business solutions in agriculture and rural development, aligning with national goals like Kenya Vision 2030 and the Agricultural Sector Development Strategy; and to collaborate with clients and provide scientific research findings to aid in informed decision-making within the sector.

### Service Category
- G2C (Government to Citizen)

### Process Objective
- To extend academic knowledge in agribusiness, co-operative rural development, and related economic sectors to various stakeholders; to enhance businesses by offering comprehensive capacity development, training, consultancy, and research services; to offer quality and specialized short courses for farmers, small-scale entrepreneurs, co-operative societies (including SACCOs), and other relevant stakeholders; to provide training in diverse fields such as agriculture, ICT, monitoring and evaluation, project management, food security, leadership, climate change, and GIS & remote sensing; to conduct consultancies focused on improving interventions and providing business solutions in agriculture and rural development, aligning with national goals like Kenya Vision 2030 and the Agricultural Sector Development Strategy; and to collaborate with clients and provide scientific research findings to aid in informed decision-making within the sector.

### Scope
- **In Scope:** End-to-end processing within Agri and Cooperative Training and Consultancy Services Limted (subsidary of Cooperative University).
- **Out of Scope:** External agency approvals.

### Triggers
- Submission of application/request by Student.

### End States
- **Successful:** Admission Letter, Student ID Card, Academic Transcripts, Degree/Diploma Certificate
- **Unsuccessful:** Application rejected due to non-compliance.

### Policy Context
- The Agri and Cooperative Training and Consultancy Services Limted (subsidary of Cooperative University) Act; The Constitution of Kenya 2010; Data Protection Act 2019.

---

## Stakeholders
| Stakeholder | Role | Responsibilities |
|---|---|---|
| Student | Process Actor | Performs actions as defined in steps. |
| Registrar | Process Actor | Performs actions as defined in steps. |

---

## Inputs & Outputs
- **Inputs:** KCSE/Academic Result Slips, National ID / Birth Certificate, Student Personal Details Form, Fee Payment Receipts
- **Outputs:** Admission Letter, Student ID Card, Academic Transcripts, Degree/Diploma Certificate

---

## Detailed Process (AS-IS)
| Step | Role | Action | Tool | Notes |
|---|---|---|---|---|
| 1 | Student | Student receives placement notification via KUCCPS or applies directly as Self-Sponsored. | Manual | |
| 2 | Student | Student logs into the Institution's Student Portal to accept admission and download Admission Letter. | Digital | |
| 3 | Student | Student pays tuition and statutory fees via Bank or eCitizen. | Manual | |
| 4 | Student | Student physically reports to the institution for document verification (original slips, certs). | Manual | |
| 5 | Registrar | Institution registers the student in the ERP system. | Manual | |
| 6 | Student | Student is issued a Student ID card. | Manual | |

---

## Pain Points & Opportunities
### Pain Points
- Long queues during admission and registration.
- Manual reconciliation of fee payments.
- Delays in processing exam results and transcripts.
- Fragmented student data across departments.

### Opportunities
- Biometric student registration and attendance.
- Integrated ERP for end-to-end student lifecycle management.
- Smart Campus Cards for access control and payments.
- E-learning and digital library integration.

---

## KPIs
| KPI | Baseline | Target |
|---|---|---|
| Turnaround Time | 30 Days | 5 Days |
| CSAT | 50% | 90% |
