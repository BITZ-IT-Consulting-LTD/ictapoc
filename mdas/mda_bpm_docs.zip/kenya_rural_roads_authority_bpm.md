# STANDARD BPM TEMPLATE – Kenya Rural Roads Authority

## Cover Page
- **Ministry/Department/Agency (MDA):** Kenya Rural Roads Authority
- **Process Name:** To construct, upgrade, rehabilitate, and maintain roads within the rural road network; to control and manage road reserves and access to roadside developments; to implement road policies specifically tailored for rural roads; to ensure compliance with axle load control regulations on rural roads; to collect, collate, and analyze data pertinent to rural road usage for effective planning; to monitor and evaluate the utilization and impact of rural roads; to prepare road work programs for all rural roads; and to coordinate with other road authorities and government agencies on integrated road network development.
- **Document Version:** 1.0
- **Date:** 2026-02-14
- **Classification:** Official

---

## Executive Summary
The Kenya Rural Roads Authority (KeRRA) is a State corporation established in 2008 under the Kenya Roads Act, 2007. Its primary mandate is to manage, develop, rehabilitate, and maintain the rural road network across Kenya. KeRRA plays a crucial role in enhancing connectivity for rural communities, facilitating the transportation of agricultural produce to markets, and supporting overall rural economic development, thereby contributing to poverty reduction and improved livelihoods.

---

## Process Flowchart (BPMN 2.0 - Mermaid)
*Guidance: This diagram visualizes the process flow across different actors (Swimlanes).*

```mermaid
graph TD
    Start((Start)) --> S1
    subgraph Agency [Agency]
        S1["Agency advertises tender on Public Procurement Inf..."]
    end
    subgraph Bidder [Bidder]
        S2["Bidder downloads tender documents and prepares bid..."]
        S3["Bidder submits bid via e-Procurement portal or ten..."]
    end
    subgraph EvaluationCommittee [Evaluation Committee]
        S4["Evaluation Committee conducts opening, technical, ..."]
    end
    subgraph AccountingOfficer [Accounting Officer]
        S5["Accounting Officer awards the tender to the lowest..."]
    end
    subgraph AgencyBidder [Agency/Bidder]
        S6["Contract is signed after the 14-day standstill per..."]
    end
    S1 --> S2
    S2 --> S3
    S3 --> S4
    S4 --> S5
    S5 --> S6
    S6 --> End((End))
```

---

## Process Overview
### Process Name
To construct, upgrade, rehabilitate, and maintain roads within the rural road network; to control and manage road reserves and access to roadside developments; to implement road policies specifically tailored for rural roads; to ensure compliance with axle load control regulations on rural roads; to collect, collate, and analyze data pertinent to rural road usage for effective planning; to monitor and evaluate the utilization and impact of rural roads; to prepare road work programs for all rural roads; and to coordinate with other road authorities and government agencies on integrated road network development.

### Service Category
- G2B (Government to Business)

### Process Objective
- To construct, upgrade, rehabilitate, and maintain roads within the rural road network; to control and manage road reserves and access to roadside developments; to implement road policies specifically tailored for rural roads; to ensure compliance with axle load control regulations on rural roads; to collect, collate, and analyze data pertinent to rural road usage for effective planning; to monitor and evaluate the utilization and impact of rural roads; to prepare road work programs for all rural roads; and to coordinate with other road authorities and government agencies on integrated road network development.

### Scope
- **In Scope:** End-to-end processing within Kenya Rural Roads Authority.
- **Out of Scope:** External agency approvals.

### Triggers
- Submission of application/request by Agency.

### End States
- **Successful:** License / Permit / Certificate, Compliance Inspection Report, Official Receipt, Gazette Notice
- **Unsuccessful:** Application rejected due to non-compliance.

### Policy Context
- The Kenya Rural Roads Authority Act; The Constitution of Kenya 2010; Data Protection Act 2019.

---

## Stakeholders
| Stakeholder | Role | Responsibilities |
|---|---|---|
| Evaluation Committee | Process Actor | Performs actions as defined in steps. |
| Accounting Officer | Process Actor | Performs actions as defined in steps. |
| Bidder | Process Actor | Performs actions as defined in steps. |
| Agency/Bidder | Process Actor | Performs actions as defined in steps. |
| Agency | Process Actor | Performs actions as defined in steps. |

---

## Inputs & Outputs
- **Inputs:** Application Form (License/Permit), Compliance Documents (Tax Compliance, CR12), Technical Reports / Site Plans, Proof of Payment
- **Outputs:** License / Permit / Certificate, Compliance Inspection Report, Official Receipt, Gazette Notice

---

## Detailed Process (AS-IS)
| Step | Role | Action | Tool | Notes |
|---|---|---|---|---|
| 1 | Agency | Agency advertises tender on Public Procurement Information Portal (PPIP) and website. | Digital | |
| 2 | Bidder | Bidder downloads tender documents and prepares bid (Technical & Financial). | Manual | |
| 3 | Bidder | Bidder submits bid via e-Procurement portal or tender box. | Digital | |
| 4 | Evaluation Committee | Evaluation Committee conducts opening, technical, and financial evaluation. | Manual | |
| 5 | Accounting Officer | Accounting Officer awards the tender to the lowest responsive bidder. | Manual | |
| 6 | Agency/Bidder | Contract is signed after the 14-day standstill period. | Manual | |

---

## Pain Points & Opportunities
### Pain Points
- Manual document verification takes time.
- High cost and time for physical inspections.
- Risk of counterfeit licenses/certificates.
- Lack of real-time monitoring of licensees.

### Opportunities
- Online Licensing Management System (LMS).
- Integration with IPRS and BRS for auto-verification.
- Mobile field inspection apps with GIS.
- QR-coded verifiable certificates.

---

## KPIs
| KPI | Baseline | Target |
|---|---|---|
| Turnaround Time | 30 Days | 5 Days |
| CSAT | 50% | 90% |
