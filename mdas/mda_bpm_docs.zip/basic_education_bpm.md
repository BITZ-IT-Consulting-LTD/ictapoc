# STANDARD BPM TEMPLATE – Basic Education

## Cover Page
- **Ministry/Department/Agency (MDA):** Basic Education
- **Process Name:** To formulate and implement policies, strategies, and programs for Early Childhood Development, Primary, and Secondary education, and for teacher training; to supervise the management of Basic Education Service Provision Institutions; to establish and maintain a comprehensive Education Information Management System (database) for basic education; to facilitate the development of basic education and teacher training across all levels; to initiate and implement strategic international, national, and institutional collaborations and partnerships for interventions in Basic Education; to ensure the implementation of nomadic education and alternative provision to basic education policies; to ensure prudent management of finances and other resources in Basic Education Institutions; to ensure the registration of all schools and colleges; to manage national examinations and certification processes; and to manage teacher and student affairs, including quality assurance in education and curriculum development.
- **Document Version:** 1.0
- **Date:** 2026-02-14
- **Classification:** Official

---

## Executive Summary
The Ministry of Education in Kenya, through its Basic Education functions, operates under a comprehensive mandate primarily enshrined in the Constitution of Kenya. It is responsible for ensuring the provision of quality basic education, encompassing Early Childhood, Primary, and Secondary education. This involves developing education policies, standards, and curriculum, and managing institutions. The Ministry aims to guarantee children's rights to free and compulsory education, promote ICT integration in learning, and foster a robust educational system that aligns with national development goals and produces skilled citizens.

---

## Process Flowchart (BPMN 2.0 - Mermaid)
*Guidance: This diagram visualizes the process flow across different actors (Swimlanes).*

```mermaid
graph TD
    Start((Start)) --> S1
    subgraph Customer [Customer]
        S1["Customer/Stakeholder submits request, application,..."]
    end
    subgraph Registry [Registry]
        S2["Registry/Front Office receives, records, and class..."]
    end
    subgraph TechnicalOfficer [Technical Officer]
        S3["Relevant Technical Department reviews the request ..."]
    end
    subgraph Management [Management]
        S4["Management/Accounting Officer approves the appropr..."]
    end
    subgraph CustomerCare [Customer Care]
        S5["Service is delivered or official response is commu..."]
    end
    S1 --> S2
    S2 --> S3
    S3 --> S4
    S4 --> S5
    S5 --> End((End))
```

---

## Process Overview
### Process Name
To formulate and implement policies, strategies, and programs for Early Childhood Development, Primary, and Secondary education, and for teacher training; to supervise the management of Basic Education Service Provision Institutions; to establish and maintain a comprehensive Education Information Management System (database) for basic education; to facilitate the development of basic education and teacher training across all levels; to initiate and implement strategic international, national, and institutional collaborations and partnerships for interventions in Basic Education; to ensure the implementation of nomadic education and alternative provision to basic education policies; to ensure prudent management of finances and other resources in Basic Education Institutions; to ensure the registration of all schools and colleges; to manage national examinations and certification processes; and to manage teacher and student affairs, including quality assurance in education and curriculum development.

### Service Category
- G2C/G2B

### Process Objective
- To formulate and implement policies, strategies, and programs for Early Childhood Development, Primary, and Secondary education, and for teacher training; to supervise the management of Basic Education Service Provision Institutions; to establish and maintain a comprehensive Education Information Management System (database) for basic education; to facilitate the development of basic education and teacher training across all levels; to initiate and implement strategic international, national, and institutional collaborations and partnerships for interventions in Basic Education; to ensure the implementation of nomadic education and alternative provision to basic education policies; to ensure prudent management of finances and other resources in Basic Education Institutions; to ensure the registration of all schools and colleges; to manage national examinations and certification processes; and to manage teacher and student affairs, including quality assurance in education and curriculum development.

### Scope
- **In Scope:** End-to-end processing within Basic Education.
- **Out of Scope:** External agency approvals.

### Triggers
- Submission of application/request by Customer.

### End States
- **Successful:** License / Permit / Certificate, Compliance Inspection Report, Official Receipt, Gazette Notice
- **Unsuccessful:** Application rejected due to non-compliance.

### Policy Context
- The Basic Education Act; The Constitution of Kenya 2010; Data Protection Act 2019.

---

## Stakeholders
| Stakeholder | Role | Responsibilities |
|---|---|---|
| Registry | Process Actor | Performs actions as defined in steps. |
| Customer Care | Process Actor | Performs actions as defined in steps. |
| Management | Process Actor | Performs actions as defined in steps. |
| Customer | Process Actor | Performs actions as defined in steps. |
| Technical Officer | Process Actor | Performs actions as defined in steps. |

---

## Inputs & Outputs
- **Inputs:** Application Form (License/Permit), Compliance Documents (Tax Compliance, CR12), Technical Reports / Site Plans, Proof of Payment
- **Outputs:** License / Permit / Certificate, Compliance Inspection Report, Official Receipt, Gazette Notice

---

## Detailed Process (AS-IS)
| Step | Role | Action | Tool | Notes |
|---|---|---|---|---|
| 1 | Customer | Customer/Stakeholder submits request, application, or inquiry via official channels (Email, Letter, or Portal). | Digital | |
| 2 | Registry | Registry/Front Office receives, records, and classifies the request. | Manual | |
| 3 | Technical Officer | Relevant Technical Department reviews the request against internal policies and regulations. | Manual | |
| 4 | Management | Management/Accounting Officer approves the appropriate action or service delivery. | Manual | |
| 5 | Customer Care | Service is delivered or official response is communicated to the customer. | Manual | |

---

## Pain Points & Opportunities
### Pain Points
- Manual document verification takes time.
- High cost and time for physical inspections.
- Risk of counterfeit licenses/certificates.
- Lack of real-time monitoring of licensees.

### Opportunities
- Online Licensing Management System (LMS).
- Integration with IPRS and BRS for auto-verification.
- Mobile field inspection apps with GIS.
- QR-coded verifiable certificates.

---

## KPIs
| KPI | Baseline | Target |
|---|---|---|
| Turnaround Time | 30 Days | 5 Days |
| CSAT | 50% | 90% |
